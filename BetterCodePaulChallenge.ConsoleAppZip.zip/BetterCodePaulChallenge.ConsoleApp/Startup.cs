﻿using BetterCodePaulChallenge.ConsoleApp.Application.Orquestration;
using BetterCodePaulChallenge.ConsoleApp.Application.Orquestration.Interfaces;
using BetterCodePaulChallenge.ConsoleApp.Domain.Contracts.Repository;
using BetterCodePaulChallenge.ConsoleApp.Infrastructure.DataProvider;
using BetterCodePaulChallenge.ConsoleApp.Infrastructure.Repository;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

namespace BetterCodePaulChallenge.ConsoleApp.Configuration
{
    public class Startup
    {
        public static IHost CreateHost()
        {
            var host = Host.CreateDefaultBuilder()
                 .ConfigureAppConfiguration((ctx, cfg) =>
                 {
                     cfg.SetBasePath(AppContext.BaseDirectory);
                     //cfg.AddJsonFile(Path.Combine("Application", "appsettings.json"), optional: true, reloadOnChange: true);
                     //cfg.AddJsonFile(Path.Combine("Application", $"appsettings.{ctx.HostingEnvironment.EnvironmentName}.json"), optional: true, reloadOnChange: true);
                     cfg.AddJsonFile("appsettings.json", optional: true, reloadOnChange: true);
                     cfg.AddJsonFile($"appsettings.{ctx.HostingEnvironment.EnvironmentName}.json", optional: true);

                     cfg.AddEnvironmentVariables();
                 })
                 .ConfigureServices((ctx, services) =>
                 {
                     //v1
                     services.Configure<AppConfig>(options =>
                     {
                         ctx.Configuration.Bind(options);


                     });

                     services.AddSingleton<FilesReader>();
                     services.AddSingleton<IWeatherRepository, WeatherRepository>();
                     services.AddSingleton<IWeatherService, WeatherService>();

                 }).Build();

            return host;
        }
    }
}
